import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidatedetails-hr',
  templateUrl: './candidatedetails-hr.component.html',
  styleUrls: ['./candidatedetails-hr.component.css']
})
export class CandidatedetailsHRComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
